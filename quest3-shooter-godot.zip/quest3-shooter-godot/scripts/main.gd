extends Node3D
## Root script for the main scene: starts the OpenXR session so the game
## renders to the Quest 3 headset instead of the flat desktop viewport.

func _ready() -> void:
	var xr_interface: XRInterface = XRServer.find_interface("OpenXR")
	if xr_interface and xr_interface.is_initialized():
		print("OpenXR initialized successfully")
		get_viewport().use_xr = true
	else:
		push_warning("OpenXR not initialized — running in flat/desktop preview mode.")
